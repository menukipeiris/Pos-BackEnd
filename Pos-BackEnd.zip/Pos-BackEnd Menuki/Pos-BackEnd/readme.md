# JavaEE POS System API

This JavaEE-based Point of Sale (POS) System API provides a simple and efficient way to manage customers, items, orders,
and order details. It is designed for ease of use in building POS applications.

## Features

### Customer Management:
- **Register New Customers:** Add new entries effortlessly.
- **Locate Existing Customers:** Quickly search for customer details.
- **Modify Customer Details:** Update existing customer information.
- **Remove Customers:** Delete customer records as needed.

### Item Management:
- **Introduce New Items:** Add new items to the inventory.
- **Find Current Items:** Search and retrieve item details.
- **Edit Item Details:** Update information for existing items.
- **Eliminate Items:** Remove items from the inventory with ease.

### Order Management:
- **Generate New Orders:** Create and process new orders.
- **Access Current Orders:** Review and manage all existing orders.

## Technologies Used

- JakarthaEE 
- Tomcat 
- MySQL 
- parsson 
- yasson 
- Postman

## Controllers and Endpoints

### Customer Controller
- **Create Customer:** `POST /customer` - Add a new customer.
- **Find Customer:** `GET /customer/{id}` - Retrieve customer details by ID.
- **Modify Customer:** `PUT /customer` - Update an existing customer's details.
- **Remove Customer:** `DELETE /customer/{id}` - Delete a customer by ID.
- **List Customers:** `GET /customer` - Get a list of all customers.

### Item Controller
- **Add Item:** `POST /item` - Add a new item to the inventory.
- **Find Item:** `GET /item/{id}` - Retrieve item details by ID.
- **Update Item:** `PUT /item` - Update information for an existing item.
- **Remove Item:** `DELETE /item/{id}` - Delete an item by ID.
- **List Items:** `GET /item` - Get a list of all items.

### Order Controller
- **Create Order:** `POST /order` - Initiate a new order.
- **List Orders:** `GET /order` - Retrieve a list of all orders.
- 
## API Documentation

Explore the detailed API documentation to understand how to integrate and leverage the functionalities of the POS system.

- [API Documentation Link](https://documenter.getpostman.com/view/30897079/2s9YsQ9AQ8)

## How to Use

1. Clone the repository. `https://github.com/ManeeshaVR/POS-Backend.git`
2. Set up your JakarthaEE environment.
3. Run Tomcat server.`version 10.1.16 or later`
4. Deploy project artifact in Tomcat server.
   `edit configuration >  deployment > add your artifact`
5. Use this [website](https://maneeshavr.github.io/POS-Frontend/) as Frontend.


## License

This project is licensed under
the [MIT LICENSE](https://github.com/ManeeshaVR/POS-Backend/blob/master/LICENSE.md)