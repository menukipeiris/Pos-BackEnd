package lk.ijse.aad.posbackend.controller;

import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lk.ijse.aad.posbackend.bo.BOFactory;
import lk.ijse.aad.posbackend.bo.custom.CustomerBO;
import lk.ijse.aad.posbackend.dto.CustomerDTO;
import lk.ijse.aad.posbackend.entity.Customer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

@WebServlet(urlPatterns = "/customer")
public class CustomerController extends HttpServlet {

    CustomerBO customerBO= (CustomerBO) BOFactory.getBoFactory().getBo(BOFactory.BOTypes.CUSTOMER);
    private Connection connection;
    Jsonb jsonb = JsonbBuilder.create();
    Logger logger = LoggerFactory.getLogger(Customer.class);


@Override
public void init() {
    logger.info("Init method invoked");
    try {
        var ctx = new InitialContext();
        DataSource pool = (DataSource) ctx.lookup("java:comp/env/jdbc/thogakade");
        this.connection = pool.getConnection();
        logger.info("Connection initialized ", this.connection);
    } catch (SQLException | NamingException e) {
        logger.error("Initialize error");
        e.printStackTrace();
    }
}


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            List<CustomerDTO> customers = customerBO.getAllCustomers(connection);

            if (!customers.isEmpty()) {
                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");

                PrintWriter writer = resp.getWriter();
                String json = jsonb.toJson(customers);
                writer.write(json);

                logger.info("Customers data send");
                resp.setStatus(HttpServletResponse.SC_OK);
            }else{
                resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getContentType() != null && req.getContentType().toLowerCase().startsWith("application/json")){
            CustomerDTO customerDTO = jsonb.fromJson(req.getReader(), CustomerDTO.class);
            System.out.println( customerDTO);
            try {
                if(customerBO.createCustomer(customerDTO, connection)){
                    logger.info("Customer is saved");

                    resp.setStatus(HttpServletResponse.SC_CREATED);
                }else{
                    logger.error("Failed to Save");
                    resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }
        }else {
            logger.error("Did not contain json ContentType");
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }


//        if (req.getContentType() == null || !req.getContentType().toLowerCase().startsWith("application/json")) {
//            resp.sendError(HttpServletResponse.SC_BAD_REQUEST);
//            logger.error("Invalid Content Type");
//            return;
//        }
//        try ( var reader = req.getReader(); var writer = resp.getWriter()) {
//
//            Jsonb jsonb = JsonbBuilder.create();
//            CustomerDTO customerDto = jsonb.fromJson(reader, CustomerDTO.class);
//
//            try {
//                if (customerBO.createCustomer(customerDto,connection)){
//                    resp.setStatus(HttpServletResponse.SC_CREATED);
//                    writer.write("Customer Added Successfully");
//                    logger.info("Customer Added Successfully");
//                }
//                else {
//                    resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//                    writer.write("Failed to add Customer");
//                    logger.error("Failed to add Customer");
//                }
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getContentType() != null && req.getContentType().toLowerCase().startsWith("application/json")){
            CustomerDTO customerDTO = jsonb.fromJson(req.getReader(), CustomerDTO.class);

            try {
                if (customerBO.updateCustomer(customerDTO, connection)){
                    logger.info("Customer is Updated");
                    resp.setStatus(HttpServletResponse.SC_OK);
                }else{
                    logger.error("Failed to Update");
                    resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }

        }else {
            logger.error("Did not contain json ContentType");
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getContentType() != null && req.getContentType().toLowerCase().startsWith("application/json")){
            CustomerDTO customerDTO = jsonb.fromJson(req.getReader(), CustomerDTO.class);

            try {
                if (customerBO.deleteCustomer(customerDTO.getCustomerId(), connection)){
                    logger.info("Customer is Deleted");
                    resp.setStatus(HttpServletResponse.SC_OK);
                }else{
                    logger.error("Failed to Delete");
                    resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }

        }else{
            logger.error("Did not contain json ContentType");
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }
}