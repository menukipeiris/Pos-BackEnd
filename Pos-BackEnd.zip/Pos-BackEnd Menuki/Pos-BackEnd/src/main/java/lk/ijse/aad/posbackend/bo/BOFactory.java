package lk.ijse.aad.posbackend.bo;

import lk.ijse.aad.posbackend.bo.custom.CustomerBO;
import lk.ijse.aad.posbackend.bo.custom.ItemBO;
import lk.ijse.aad.posbackend.bo.custom.impl.CustomerBOImpl;
import lk.ijse.aad.posbackend.bo.custom.impl.ItemBOImpl;

public class BOFactory {

    private static BOFactory boFactory;

    private BOFactory() {}

    public static BOFactory getBoFactory() {
        if (boFactory == null) {
            boFactory = new BOFactory();
        }
        return boFactory;
    }

    public enum BOTypes {
        CUSTOMER, ITEM, ORDER, ORDER_DETAILS
    }

    public SuperBO getBo(BOTypes boTypes) {
        switch (boTypes) {
            case CUSTOMER:
                return new CustomerBOImpl();
            case ITEM:
                return new ItemBOImpl();

            default:
                return null;
        }
    }
}
