package lk.ijse.aad.posbackend.dao.custom;

import lk.ijse.aad.posbackend.dao.CrudDAO;
import lk.ijse.aad.posbackend.entity.Customer;

public interface CustomerDAO extends CrudDAO<Customer,String> {
}
