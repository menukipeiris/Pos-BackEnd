package lk.ijse.aad.posbackend.dao.custom;

import lk.ijse.aad.posbackend.dao.CrudDAO;
import lk.ijse.aad.posbackend.entity.Order;

public interface OrderDAO extends CrudDAO<Order,String> {
}
