package lk.ijse.aad.posbackend.bo.custom.impl;

import lk.ijse.aad.posbackend.bo.custom.ItemBO;
import lk.ijse.aad.posbackend.dao.DAOFactory;
import lk.ijse.aad.posbackend.dao.custom.ItemDAO;
import lk.ijse.aad.posbackend.dto.ItemDTO;
import lk.ijse.aad.posbackend.entity.Item;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemBOImpl implements ItemBO {

    ItemDAO itemDAO= (ItemDAO) DAOFactory.getDaoFactory().getDAO(DAOFactory.DAOTypes.ITEM);
    @Override
    public boolean createItem(ItemDTO itemDTO, Connection connection) throws SQLException {
        System.out.println("itemDTOBoImpl = " + itemDTO);
        return itemDAO.save(connection,new Item(
                itemDTO.getItemId(),
                itemDTO.getDescription(),
                itemDTO.getQty(),
                itemDTO.getPrice()
        ));
    }

    @Override
    public boolean updateItem(ItemDTO itemDTO, Connection connection) throws SQLException {
        return itemDAO.update(connection,new Item(
                itemDTO.getItemId(),
                itemDTO.getDescription(),
                itemDTO.getQty(),
                itemDTO.getPrice()
        ));
    }

    @Override
    public boolean deleteItem(String itemId, Connection connection) throws SQLException {
        return itemDAO.delete(connection,itemId);
    }

    @Override
    public List<ItemDTO> getAllItems(Connection connection) throws SQLException {
        List<Item>items=itemDAO.getAll(connection);
        List<ItemDTO>itemDTOS=new ArrayList<>();
        for (Item item:items){
            itemDTOS.add(new ItemDTO(
                    item.getItemId(),
                    item.getDescription(),
                    item.getQty(),
                    item.getPrice()
            ));
        }
        return itemDTOS;
    }
}
