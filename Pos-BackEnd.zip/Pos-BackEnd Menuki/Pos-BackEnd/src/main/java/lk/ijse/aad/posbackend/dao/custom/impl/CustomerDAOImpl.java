package lk.ijse.aad.posbackend.dao.custom.impl;

import lk.ijse.aad.posbackend.util.SQLUtil;
import lk.ijse.aad.posbackend.dao.custom.CustomerDAO;
import lk.ijse.aad.posbackend.entity.Customer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAOImpl implements CustomerDAO {

    private static final String GET_QUERY = "select * from customer";
//    private static final String SAVE_QUERY = "insert into customer values(cust_id,cust_name,cust_address,cust_salary)";
private static final String SAVE_QUERY = "INSERT INTO customer (cust_id, cust_name, cust_address, cust_salary) VALUES (?, ?, ?, ?)";

    private static final String UPDATE_QUERY="update customer set cust_name=? , cust_address=? , cust_salary=? where cust_id=?";
    private static final String DELETE_QUERY = "delete from customer where cust_id=?";


    @Override
    public List<Customer> getAll(Connection connection) throws SQLException {
        ResultSet rs= SQLUtil.exeute(connection, GET_QUERY);
        List<Customer> customers = new ArrayList<>();
        while (rs.next()) {
            customers.add(new Customer(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getInt(4)
            ));
        }
        return customers;
    }

//    @Override
//    public boolean save(Connection connection,Customer dto) throws SQLException {
//        System.out.println("dto = " + dto);
//        return SQLUtil.exeute(connection,
//                SAVE_QUERY,
//                dto.getCustomerId(),
//                dto.getName(),
//                dto.getAddress(),
//                dto.getSalary()
//        );
//    }
@Override
public boolean save(Connection connection, Customer dto) throws SQLException {
    System.out.println("dto = " + dto);
    return SQLUtil.exeute(connection,
            SAVE_QUERY,
            dto.getCustomerId(),
            dto.getName(),
            dto.getAddress(),
            dto.getSalary()
    );
}
    @Override
    public boolean update(Connection connection,Customer dto) throws SQLException {
        return SQLUtil.exeute(connection,
                UPDATE_QUERY,
                dto.getName(),
                dto.getAddress(),
                dto.getSalary(),
                dto.getCustomerId()

        );
    }

    @Override
    public boolean delete(Connection connection,String customerId) throws SQLException {
        return SQLUtil.exeute(connection,DELETE_QUERY,customerId);
    }
}
