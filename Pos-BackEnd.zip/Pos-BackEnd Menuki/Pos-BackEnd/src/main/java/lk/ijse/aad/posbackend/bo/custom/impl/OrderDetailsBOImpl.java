package lk.ijse.aad.posbackend.bo.custom.impl;

import lk.ijse.aad.posbackend.bo.custom.OrderDetailsBO;
import lk.ijse.aad.posbackend.dao.DAOFactory;
import lk.ijse.aad.posbackend.dao.custom.ItemDAO;
import lk.ijse.aad.posbackend.dao.custom.OrderDetailsDAO;
import lk.ijse.aad.posbackend.dto.OrderDetailsDTO;
import lk.ijse.aad.posbackend.entity.OrderDetails;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDetailsBOImpl implements OrderDetailsBO {
    OrderDetailsDAO orderDetailsDAO= (OrderDetailsDAO) DAOFactory.getDaoFactory().getDAO(DAOFactory.DAOTypes.ORDER_DETAILS);
    ItemDAO itemDAO= (ItemDAO) DAOFactory.getDaoFactory().getDAO(DAOFactory.DAOTypes.ITEM);

    @Override
    public List<OrderDetailsDTO> getOrderDetails(Connection connection) throws SQLException {
       List<OrderDetails>details=orderDetailsDAO.getAll(connection);
       List<OrderDetailsDTO>detailsDTOS=new ArrayList<>();
       for(OrderDetails od:details){
           detailsDTOS.add(new OrderDetailsDTO(
                   od.getOrderId(),
                   od.getItemId(),
                   od.getQty()
           ));
       }
        return detailsDTOS;
    }

    @Override
    public boolean saveOrderDetails(List<OrderDetailsDTO> details, Connection connection) throws SQLException {

        connection.setAutoCommit(false);

        for (OrderDetailsDTO detail:details){

            if (!orderDetailsDAO.save(connection,new OrderDetails(detail.getOrderId(),detail.getItemId(),detail.getQty()))){
                connection.rollback();
                connection.setAutoCommit(true);
                return false;
            }

//        should add    Item item=itemDAO.g
        }
        connection.commit();
        connection.setAutoCommit(true);
        return true;
    }
}
