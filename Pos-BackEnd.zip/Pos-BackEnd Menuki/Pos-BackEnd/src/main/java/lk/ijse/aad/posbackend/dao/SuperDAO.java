package lk.ijse.aad.posbackend.dao;

public interface SuperDAO {
}
