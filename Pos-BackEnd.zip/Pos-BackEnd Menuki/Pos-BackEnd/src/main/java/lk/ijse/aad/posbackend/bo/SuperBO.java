package lk.ijse.aad.posbackend.bo;

public interface SuperBO {
}
