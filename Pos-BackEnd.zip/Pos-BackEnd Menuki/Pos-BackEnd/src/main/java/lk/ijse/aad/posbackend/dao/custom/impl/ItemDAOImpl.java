package lk.ijse.aad.posbackend.dao.custom.impl;

import lk.ijse.aad.posbackend.util.SQLUtil;
import lk.ijse.aad.posbackend.dao.custom.ItemDAO;
import lk.ijse.aad.posbackend.entity.Item;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemDAOImpl implements ItemDAO {

    private static final String GET_QUERY ="select * from item";
//    private static final String SAVE_QUERY = "insert into item values(item_id,item_name,item_qty,item_price)";

    private static final String SAVE_QUERY = "insert into item(item_id,item_name,item_qty,item_price) VALUES (?, ?, ?, ?)";
    private static final String UPDATE_QUERY= "update item set item_name=?,item_qty=?,item_price=? where item_id=?";
    private static final String DELETE_QUERY = "delete from item where item_id=?";

    @Override
    public List<Item> getAll(Connection connection) throws SQLException {
        ResultSet rs = SQLUtil.exeute(connection, GET_QUERY);
        List<Item> items = new ArrayList<>();

        while (rs.next()) {
            items.add(new Item(
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getDouble(4)
            ));
        }
            return items;
    }

    @Override
    public boolean save(Connection connection, Item dto) throws SQLException {
        System.out.println("dto = " + dto);
        return SQLUtil.exeute(connection,
                SAVE_QUERY,
                dto.getItemId(),
                dto.getDescription(),
                dto.getPrice(),
                dto.getQty()
        );
    }

    @Override
    public boolean update(Connection connection, Item dto) throws SQLException {
        return SQLUtil.exeute(connection,
                UPDATE_QUERY,
                dto.getDescription(),
                dto.getPrice(),
                dto.getQty(),
                dto.getItemId()
                );
    }

    @Override
    public boolean delete(Connection connection, String s) throws SQLException {
        return SQLUtil.exeute(connection,DELETE_QUERY,s);
    }
}
