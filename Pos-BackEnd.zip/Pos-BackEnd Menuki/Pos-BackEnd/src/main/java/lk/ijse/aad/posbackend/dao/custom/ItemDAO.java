package lk.ijse.aad.posbackend.dao.custom;

import lk.ijse.aad.posbackend.dao.CrudDAO;
import lk.ijse.aad.posbackend.entity.Item;

public interface ItemDAO extends CrudDAO<Item,String> {
}
