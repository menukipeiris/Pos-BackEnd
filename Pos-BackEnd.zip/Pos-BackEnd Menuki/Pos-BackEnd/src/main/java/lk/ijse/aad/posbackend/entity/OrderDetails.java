package lk.ijse.aad.posbackend.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class OrderDetails {
    private String orderId;
    private String itemId;
    private Integer qty;
}
