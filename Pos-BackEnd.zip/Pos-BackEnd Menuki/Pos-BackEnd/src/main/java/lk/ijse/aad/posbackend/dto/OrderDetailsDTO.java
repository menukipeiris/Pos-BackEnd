package lk.ijse.aad.posbackend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data

public class OrderDetailsDTO {
    private String orderId;
    private String itemId;
    private Integer qty;
}
