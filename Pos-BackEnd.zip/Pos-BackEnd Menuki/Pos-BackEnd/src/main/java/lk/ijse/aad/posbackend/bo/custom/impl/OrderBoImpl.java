package lk.ijse.aad.posbackend.bo.custom.impl;

import lk.ijse.aad.posbackend.bo.custom.OrderBO;
import lk.ijse.aad.posbackend.dao.DAOFactory;
import lk.ijse.aad.posbackend.dao.custom.OrderDAO;
import lk.ijse.aad.posbackend.dto.OrderDTO;
import lk.ijse.aad.posbackend.entity.Order;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderBoImpl implements OrderBO {

    OrderDAO orderDAO = (OrderDAO) DAOFactory.getDaoFactory().getDAO(DAOFactory.DAOTypes.ORDER);
    @Override
    public boolean saveOrder(OrderDTO orderDTO, Connection connection) throws SQLException {
        return orderDAO.save(connection,new Order(
                orderDTO.getOrderId(),
                orderDTO.getDate(),
                orderDTO.getDiscount(),
                orderDTO.getTotal(),
                orderDTO.getCustomerId()
        ));
    }

    @Override
    public List<OrderDTO> getAllOrders(Connection connection) throws SQLException {
        List<Order> orders = orderDAO.getAll(connection);
        List<OrderDTO> orderDTOs = new ArrayList<>();
        for (Order order : orders) {
            orderDTOs.add(new OrderDTO(
                    order.getOrderId(),
                    order.getDate(),
                    order.getDiscount(),
                    order.getTotal(),
                    order.getCustomerId()
            ));
        }
        return List.of();
    }
}
