package lk.ijse.aad.posbackend.bo.custom.impl;

import lk.ijse.aad.posbackend.bo.custom.CustomerBO;
import lk.ijse.aad.posbackend.dao.DAOFactory;
import lk.ijse.aad.posbackend.dao.custom.CustomerDAO;
import lk.ijse.aad.posbackend.dto.CustomerDTO;
import lk.ijse.aad.posbackend.entity.Customer;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerBOImpl implements CustomerBO {

    CustomerDAO customerDAO= (CustomerDAO) DAOFactory.getDaoFactory().getDAO(DAOFactory.DAOTypes.CUSTOMER);

    @Override
    public boolean createCustomer(CustomerDTO customerDTO, Connection connection) throws SQLException {
        System.out.println("customerDTO = " + customerDTO);
        return customerDAO.save(connection,new Customer(
                customerDTO.getCustomerId(),
                customerDTO.getName(),
                customerDTO.getAddress(),
                customerDTO.getSalary()
        ));
    }

    @Override
    public boolean updateCustomer(CustomerDTO customerDTO, Connection connection) throws SQLException {
        return customerDAO.update(connection,new Customer(
                customerDTO.getCustomerId(),
                customerDTO.getName(),
                customerDTO.getAddress(),
                customerDTO.getSalary()
        ));
    }

    @Override
    public boolean deleteCustomer(String customerId, Connection connection) throws SQLException {
        return customerDAO.delete(connection,customerId);
    }

    @Override
    public List<CustomerDTO> getAllCustomers(Connection connection) throws SQLException {
        List<Customer>customers=customerDAO.getAll(connection);
        List<CustomerDTO>customerDTOs=new ArrayList<>();
        for (Customer customer:customers){
            customerDTOs.add(new CustomerDTO(
                    customer.getCustomerId(),
                    customer.getName(),
                    customer.getAddress(),
                    customer.getSalary()
            ));
        }
        return customerDTOs;
    }
}
