package lk.ijse.aad.posbackend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class ItemDTO {
    private String itemId;
    private String description;
    private String qty;
    private double price;
}
