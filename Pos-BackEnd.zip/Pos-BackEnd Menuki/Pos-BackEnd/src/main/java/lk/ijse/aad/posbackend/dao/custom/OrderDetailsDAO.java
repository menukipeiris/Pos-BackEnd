package lk.ijse.aad.posbackend.dao.custom;

import lk.ijse.aad.posbackend.dao.CrudDAO;
import lk.ijse.aad.posbackend.entity.OrderDetails;

public interface OrderDetailsDAO extends CrudDAO<OrderDetails,String> {
}
